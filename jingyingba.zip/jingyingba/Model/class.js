




module.exports = mongoose.model("class",classSchema,"class")