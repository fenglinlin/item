var wechat =document.querySelector('.wechat');
var wexin =document.querySelector('.wexin');
var blog =document.querySelector('.blog');
var weibo =document.querySelector('.weibo');
var app =document.querySelector('.app');
var appDiv =document.querySelector('.footer_right div');
wechat.onmousemove =function(){
    wexin.style.display = 'block';
}
wechat.onmouseout = function(){
    wexin.style.display ='none';
}
blog.onmousemove =function(){
    weibo.style.display = 'block';
}
blog.onmouseout = function(){
    weibo.style.display ='none';
}
app.onmouseover =function () {
    appDiv.style.display ='block';
}
app.onmouseout =function(){
    appDiv.style.display ='none';
}