window.onload = function() {
    var btn =document.querySelectorAll('.banner_btn');
    var pics =document.querySelectorAll('.banner_cont ul li');
    var banner=document.querySelector('.banner');
    var pre =document.querySelector('.banner_left');
    var next =document.querySelector('.banner_right');
    var length =btn.length;
    var index=0;
    banner.onmouseover =function () {
        for (var i=0;i<length;i++){
            btn[i].style.display ='block';
        }
    }
    banner.onmouseout =function () {
        for (var i=0;i<length;i++){
            btn[i].style.display ='none';
        }
    }
    next.onclick=function(){
        xiaYiGe();
    }
    pre.onclick= function(){
        shangYiGe();
    }
    function shangYiGe(){
        index ++;
        if(index > pics.length-1){
            index = 0;
        }
        for(var i = 0;i<pics.length;i++){
            pics[i].style.marginLeft = 0;
        }
        pics[index].style.marginLeft = -1232+"px";
    }
    function xiaYiGe(){
        index ++;
        if(index > pics.length-1){
            index = 0;
        }
        for(var i = 0;i<pics.length;i++){
            pics[i].style.marginLeft = 0

        }
        pics[index].style.marginLeft = 1232+'px'
    }
    timer = setInterval(xiaYiGe,3000);
}