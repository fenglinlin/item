window.onload = function() {
    var btn = document.querySelectorAll('.curriculum_cont li');
    var p =document.querySelectorAll('.curriculum_cont li a p');
    var span =document.querySelectorAll('.curriculum_cont li a span');
    var iPic =document.querySelectorAll('.curriculum_cont li a i');
    var em =document.querySelectorAll('.curriculum_cont li a div em');
    var length = btn.length;
    var index = 0;
    console.log(iPic);
    var flag =0.1;
    for (var i = 0; i <length-1; i++) {
        btn[i].index = i;
        btn[i].onmousemove = function () {
            for (var i = 0; i <length-1; i++) {
                btn[i].className = '';
                p[i].style.color ='';
                iPic[i].style.display ='none';
                span[i].style.display ='block';
                btn[i].style.top = '0';
            }
            btn[this.index].className = 'on';
            p[this.index].style.color ='#fb6c03';
            iPic[this.index].style.display='block';
            span[this.index].style.display='none';
            btn[this.index].style.top = '-10px';
        }
        btn[i].onmouseout =function(){
            for (var i = 0; i <length-1; i++) {
                btn[i].className = '';
                p[i].style.color ='';
                iPic[i].style.display ='none';
                span[i].style.display ='block';
                btn[i].style.top = '0';
            }
        }
    }
    for (var i = length-1; i <length; i++) {
        btn[i].index = i;
        btn[i].onmousemove = function () {
            for (var i = length-1; i <length; i++) {
                btn[i].className = '';
                p[i].style.color ='';
            }
            for(var i=0;i<em.length;i++){
                em[i].className = 'em';
            }
            btn[this.index].className = 'on';
            p[this.index].style.color ='#fb6c03';
            btn[this.index].style.top = '-10px';
        }
        btn[i].onmouseout =function(){
            for (var i = length-1; i <length; i++) {
                btn[i].className = '';
                p[i].style.color ='';
                btn[i].style.top = '0';
            }
            for(var i=0;i<em.length;i++){
                em[i].className = '';
            }
        }
    }
}